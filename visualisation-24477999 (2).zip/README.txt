You can put static files in this directory.
